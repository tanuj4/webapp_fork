#!/bin/bash
set -e

# Set DEBIAN_FRONTEND to noninteractive to avoid dialog prompts during package installation
export DEBIAN_FRONTEND=noninteractive

# Update package lists
sudo apt-get update

# Install required packages
sudo apt-get install -y unzip curl

# Node.js v18.X setup
curl -sL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version

# Install MySQL
sudo apt-get install -y mysql-server

# Secure MySQL installation (automated)
MYSQL_ROOT_PASSWORD="${DB_ROOT_PASSWORD}"
DB_USER="${DB_USER}"
DB_USER_PASSWORD="${DB_USER_PASSWORD}"
DB_NAME="${DB_NAME}"

# Update root password
sudo mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '${MYSQL_ROOT_PASSWORD}';"

# Remove anonymous users and test database
sudo mysql -e "DELETE FROM mysql.user WHERE User='';"
sudo mysql -e "DROP DATABASE IF EXISTS test;"
sudo mysql -e "FLUSH PRIVILEGES;"

# Create new database
sudo mysql -u root -p"${MYSQL_ROOT_PASSWORD}" -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME};"

# Create new user only if it doesn't already exist
if ! sudo mysql -u root -p"${MYSQL_ROOT_PASSWORD}" -e "SELECT User FROM mysql.user WHERE User='${DB_USER}';" | grep -q "${DB_USER}"; then
    sudo mysql -u root -p"${MYSQL_ROOT_PASSWORD}" -e "CREATE USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_USER_PASSWORD}';"
    sudo mysql -u root -p"${MYSQL_ROOT_PASSWORD}" -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';"
    sudo mysql -u root -p"${MYSQL_ROOT_PASSWORD}" -e "FLUSH PRIVILEGES;"
else
    echo "User '${DB_USER}' already exists. Skipping user creation."
fi

sudo mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_ROOT_PASSWORD}';"

# Optional: Install your application (if applicable)
# cd /path/to/your/app && npm install

echo "MySQL installation and configuration completed."