#!/bin/bash
set -e

# Create a folder for the application
sudo mkdir -p /home/csye6225/webapp
sudo mkdir -p /var/log/webapp
sudo chown csye6225:csye6225 /var/log/webapp

# Unzip the application into the correct directory
sudo unzip /tmp/webapp.zip -d /home/csye6225/webapp

# Remove the zip after extracting
sudo rm /tmp/webapp.zip

# Install Node.js dependencies
# Update the path to point to the extracted location where package.json is
sudo npm install --prefix /home/csye6225/webapp/webapp/

# Change ownership of the application directory
sudo chown -R csye6225:csye6225 /home/csye6225/webapp/

# Move the webapp.service to the systemd path
sudo cp /home/csye6225/webapp/webapp/webapp.service /etc/systemd/system/webapp.service

# Reload systemd and enable the webapp
sudo systemctl daemon-reload
sudo systemctl start webapp
sudo systemctl enable webapp
