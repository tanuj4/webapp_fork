#!/bin/bash
set -e

# Create a user group
sudo groupadd -f csye6225

# Add a user with no login shell and add them to the csye6225 group
sudo useradd -s /usr/sbin/nologin -g csye6225 csye6225
